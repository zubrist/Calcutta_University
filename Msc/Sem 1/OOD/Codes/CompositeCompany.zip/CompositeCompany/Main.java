package CompositeCompany;

public class Main {

	public static void main(String[] args) {
		Employee HEAD = new Employee("Sunirmal Khatua", "CEO", 115000);
		
		Employee mng1 = new Employee("Budhaditya Sarkar", "Sales Management", 92000);
		Employee mng2 = new Employee("Alapan Sardar", "Market Management", 95000);
		
		Employee HSL1 = new Employee("Soumik Dey", "Head Sales", 77500);
		Employee HSL2 = new Employee("Soumik Bhowmick", "Head Sales", 84500);
		Employee HMR1 = new Employee("Sudipta Maity", "Head Marketing", 82500);
		Employee HMR2 = new Employee("Nirupam Mondal", "Head Marketing", 82500);
		
		Employee SL1 = new Employee("Ankita Mondal", "Sales", 55500);
		Employee SL2 = new Employee("Riya Ghosh", "Sales", 74500);
		Employee SL3 = new Employee("Sampurna Bhattacharya", "Sales", 56500);
		Employee SL4 = new Employee("Sritama Mandal", "Sales", 56500);
		Employee CLK1 = new Employee("Bilas Das", "Marketing", 55500);
		Employee CLK2 = new Employee("Snehasree Mistry", "Marketing", 66500);
		Employee CLK3 = new Employee("Sukanya Saha", "Marketing", 64500);
		
		// Add more employees as per your requirement //
		// Now build the Hierarchy //
		
		HEAD.add(mng1); 
		HEAD.add(mng2);
		
		mng1.add(HSL1); HSL1.add(SL1); HSL1.add(SL2);
		mng1.add(HSL2); HSL2.add(SL3); HSL2.add(SL4);
		
		mng2.add(HMR1); HMR1.add(CLK1);
		mng2.add(HMR2); HMR2.add(CLK2); HMR2.add(CLK3);
		
		// Complete Hierarchy has been built //
		
		// print the hierarchy //
//		System.out.println(HEAD);
//		for(Employee managers : HEAD.getSubemployees()) {
//			
//			System.out.println("\t"+managers);
//			
//			for(Employee HeadSLMR : managers.getSubemployees()) {
//				
//				System.out.println("\t\t"+HeadSLMR);
//				
//				for(Employee SLMR : HeadSLMR.getSubemployees()) {
//					
//					System.out.println("\t\t\t"+SLMR);
//				}
//			}
//		}
		System.out.println(HEAD);
		Employee.displayHierarchy(HEAD);
		
		System.out.println(HMR2.getTotalSalary());
		System.out.println(mng1.getTotalSalary());
	}
}
