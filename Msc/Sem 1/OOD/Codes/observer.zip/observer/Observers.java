package observer;

public interface Observers {
	void Notification(String mssg);
}

class Users implements Observers {
	private int ID;
	private String name;
	
	Users(int id, String name) {
		this.ID  = id;
		this.name = name;
	}
	
	@Override
	public void Notification(String mssg) {
		System.out.println("Message to "+name+" ("+ID+") : "+mssg);
		
	}
	
}