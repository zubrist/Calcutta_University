package observer;

public class Netflix {
	public static void main(String[] args) {
		NetflixPremium np = new NetflixPremium();
		
		Users u1 = new Users(100, "Budhaditya Sarkar");
		Users u2 = new Users(101, "Sayantan Das");
		Users u3 = new Users(102, "Sanchalan Sengupta");
		Users u4 = new Users(103, "Subham Bhattacharya");
		
		np.subscribe(u1);
		np.subscribe(u2);
		np.subscribe(u3);
		np.subscribe(u4);
		
		np.notifyALL("Drishyam 2 is coming soon");
		
		np.unsubscribe(u3);
		
		np.notifyALL("Pathan Movie is breaking all records");
		
	}
}
