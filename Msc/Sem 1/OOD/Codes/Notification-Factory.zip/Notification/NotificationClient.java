package Notification;

import java.util.Scanner;

public class NotificationClient {
	
	//public static NotificationService getType(String s) { return NotificationFactory.getNotification(s); }
	
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Enter type : ");
			String type = sc.nextLine();
			
//			NotificationService notify = getType(type);
			NotificationService notify = NotificationFactory.getNotification(type);
			if (notify != null) notify.buzzer();
			else System.out.println("Service not found !");
		}
	}
}
