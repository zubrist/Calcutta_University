package observer;

import java.util.ArrayList;
import java.util.List;

public class NetflixPremium {
	private List<Users> users = new ArrayList<Users>();
	
	public void subscribe(Users o) {
		users.add(o);
	}
	
	public void unsubscribe(Users o) {
		users.remove(o);
	}
	
	public void notifyALL(String mssg) {
		for(Users i: users) {
			i.Notification(mssg);
		}
	}
	
}
