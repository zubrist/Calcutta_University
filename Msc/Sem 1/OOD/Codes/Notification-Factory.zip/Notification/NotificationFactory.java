package Notification;

public class NotificationFactory {
	public static NotificationService getNotification (String s) {
		if (s.equals("sms")) return new SMS();
		else if (s.equals("mail")) return new MAIL();
		else if (s.equals("push")) return new PUSH();
		else if (s.equals("whatsapp")) return new WTSP();
		
		else return null;
	}
}
