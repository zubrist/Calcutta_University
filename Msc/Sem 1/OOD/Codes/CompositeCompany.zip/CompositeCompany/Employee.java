package CompositeCompany;

import java.util.ArrayList;
import java.util.List;

public class Employee {
	private String name;
	private String dept;
	private int salary;
	private List<Employee> subemployees;
	
	public Employee(String name, String dept, int salary) {
		this.name = name;
		this.dept = dept;
		this.salary = salary;
		subemployees = new ArrayList<Employee>();
	}
	
	public void add(Employee e) {
		subemployees.add(e);
	}
	
	public void remove(Employee e) {
		subemployees.remove(e);
	}
	
	public List<Employee> getSubemployees() {
		return subemployees;
	}
	
	public int getTotalSalary() {
		int TotalSalary = salary;
		for(Employee e : subemployees)
			TotalSalary = TotalSalary + e.getTotalSalary();
		return TotalSalary;
	}
	
	public static void displayHierarchy(Employee heademp) {
		if (!heademp.getSubemployees().isEmpty()) {
			for(Employee Emp: heademp.getSubemployees()) {
				System.out.println(Emp);
				
				displayHierarchy(Emp);
			}
		}
	}
	
//	public void promote() {
//		
//	}
	
	public String toString() {
		return (name+"("+dept+", "+salary+")");
		//return name;
	}
}
