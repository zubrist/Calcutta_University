package Notification;

public interface NotificationService {
	void buzzer();
}

class SMS implements NotificationService {
	@Override
	public void buzzer() {
		System.out.println("SMS sent !");
	}
}

class MAIL implements NotificationService {
	@Override
	public void buzzer() {
		System.out.println("MAIL sent !");
	}
}

class PUSH implements NotificationService {
	@Override
	public void buzzer() {
		System.out.println("PUSH sent !");	
	}
}

class WTSP implements NotificationService {
	@Override
	public void buzzer() {
		System.out.println("Whatsapp sent !");
	}
}